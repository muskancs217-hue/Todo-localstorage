import React, { useState, useEffect } from "react";

export default function App() {
  const [input, setInput] = useState("");
  const [tasks, setTasks] = useState([]);
  const [editIndex, setEditIndex] = useState(null);

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem("tasks")) || [];
    setTasks(stored);
  }, []);

  useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }, [tasks]);

  const isValid = (t) => /^[a-zA-Z0-9 _-]+$/.test(t);

  const handleAddOrUpdate = () => {
    if (!input.trim() || !isValid(input)) {
      alert("please enter a valid text (letters, numbers, space, - or _ )");
      return;
    }
    if (editIndex !== null) {
      if(window.confirm("Update this task?")){
        const copy = [...tasks];
        copy[editIndex].text = input;
        setTasks(copy);
        setEditIndex(null);
      }
    } else {
      setTasks([...tasks, { text: input, completed: false }]);
    }
    setInput("");
  };

  const handleDelete = (i) => {
    if (window.confirm("Are you sure you want to delete this task?")) {
      setTasks(tasks.filter((_, index) => index !== i));
    }
  }

  const handleEdit = (i) => {
    setInput(tasks[i].text);
    setEditIndex(i);
  }

  const toggleComplete = (i) => {
    const copy = [...tasks];
    copy[i].completed = !copy[i].completed;
    setTasks(copy);
  }

  const styles = {
    constiner: {maxWidth: 420, marginLeft: "20px", padding: 20, border: "1px solid #ccc", borderRadius: 5},
    inputRow: {display: "flex",gap: 8, marginBottom: 10},
    input: {flex: 1, padding:8 },
    btn: {padding: "8px 12 px", cursor: "pointer" },
    list: {listStyle: "none", padding: 0, margin: 0 },
    item: {display: "flex", justifyContent: "space-between", padding: 0, borderBottom: "1px solid #eee"},  
    smBtn: {marginLeft: 6, cursor: "pointer"},
  } 



  return (
    <div style={styles.constiner}>
      <h1> Todo List</h1>
      <div style={styles.inputRow}>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Enter a task ..."
          style={styles.input}
        />
        <button onClick={handleAddOrUpdate} style={styles.btn}>
          {editIndex !== null ? "Update" : "Add"}
        </button>
      </div>
      <ul style={styles.list}>
        {tasks.map((t, i) => (
          <li key={i} style={{...styles.item, textDecoration: t.completed ? "line-through" : "none"}}>
            <span
              onClick={() => toggleComplete(i)}
            >
              {t.text}
            </span>
            <div>
              <button onClick={() => handleEdit(i)} style={styles.smBtn}>Edit</button>
              <button onClick={() => handleDelete(i)} style={styles.smBtn}>Delete</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
